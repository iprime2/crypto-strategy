//! Vanilla GoDark MM bot — devnet REST + HPKE (proven on devnet).
//!
//! Flow: REST connect (auth/token) → user_uuid → one-shot HPKE per place/cancel.
//! HPKE pin must match the deployment frontend (see gdx-web VITE_GDX_HPKE_STATIC_PUBKEY).

use std::env;
use std::time::Duration;

use godark::{
    Environment, GodarkError, GodarkRestClient, OrderType, Side, TimeInForce,
};
use tokio::signal;
use tracing::{error, info, warn};

const DEFAULT_SYMBOL: &str = "BTC-USDC-PERP";

fn env_first(names: &[&str]) -> Option<String> {
    names
        .iter()
        .filter_map(|n| env::var(n).ok())
        .map(|s| s.trim().to_string())
        .find(|s| !s.is_empty())
}

fn env_f64(name: &str, default: f64) -> f64 {
    env_first(&[name])
        .and_then(|s| s.parse().ok())
        .unwrap_or(default)
}

fn hpke_pin() -> Option<String> {
    env_first(&[
        "GODARK_DEVNET_HPKE_STATIC_PUBLIC_KEY",
        "GDX_HPKE_STATIC_PUBLIC_KEY",
        "GODARK_HPKE_STATIC_PUBLIC_KEY",
        "VITE_GDX_HPKE_STATIC_PUBKEY",
    ])
}

fn rest_url(devnet: bool) -> String {
    if devnet {
        env_first(&["GODARK_DEVNET_REST_URL", "GDX_REST_URL"])
            .unwrap_or_else(|| "https://api.devnet.godark-dex.com".into())
    } else {
        env_first(&["GODARK_REST_URL", "GDX_REST_URL"])
            .unwrap_or_else(|| "https://api.godark-dex.com".into())
    }
}

fn build_rest_client() -> Result<GodarkRestClient, GodarkError> {
    let devnet = env_first(&["GODARK_ENV"])
        .map(|v| v.eq_ignore_ascii_case("devnet"))
        .unwrap_or(false);

    let (key_id, secret, passphrase) = if devnet {
        (
            env_first(&["GODARK_DEVNET_API_KEY_ID", "GDX_API_KEY_ID"]),
            env_first(&["GODARK_DEVNET_API_SECRET", "GDX_API_SECRET"]),
            env_first(&["GODARK_DEVNET_PASSPHRASE", "GDX_PASSPHRASE"]),
        )
    } else {
        (
            env_first(&["GODARK_API_KEY_ID", "GDX_API_KEY_ID"]),
            env_first(&["GODARK_API_SECRET", "GDX_API_SECRET"]),
            env_first(&["GODARK_PASSPHRASE", "GDX_PASSPHRASE"]),
        )
    };

    let (key_id, secret, passphrase) = match (key_id, secret, passphrase) {
        (Some(k), Some(s), Some(p)) => (k, s, p),
        _ => {
            return Err(GodarkError::Config(
                "missing API credentials (GODARK_DEVNET_* or GODARK_*)".into(),
            ))
        }
    };

    let mut builder = GodarkRestClient::builder()
        .rest_base_url(rest_url(devnet))
        .api_key_id(key_id)
        .api_secret(secret)
        .passphrase(passphrase);

    if devnet {
        builder = builder.environment(Environment::Devnet);
    }

    if let Some(pin) = hpke_pin() {
        builder = builder.hpke_static_public_key_hex(pin);
    }

    if let Some(uid) = env_first(&[
        "GODARK_DEVNET_USER_UUID",
        "GODARK_USER_UUID",
        "GDX_USER_UUID",
    ]) {
        builder = builder.user_uuid(uid);
    }

    builder.build()
}

fn half_spread_bps(configured_bps: f64, maker_fee_bps: f64) -> f64 {
    2.0 * maker_fee_bps + configured_bps.max(10.0)
}

fn round_to_tick(price: f64, tick: f64) -> f64 {
    if tick <= 0.0 {
        return price;
    }
    let steps = (price / tick).round();
    (steps * tick * 1e10).round() / 1e10
}

fn quote_prices(
    fair: f64,
    inventory: f64,
    max_inventory: f64,
    spread_bps: f64,
    skew_bps: f64,
    tick: f64,
) -> Result<(f64, f64, f64), String> {
    let ratio = if max_inventory <= 0.0 {
        0.0
    } else {
        (inventory / max_inventory).clamp(-1.0, 1.0)
    };
    let reservation = fair * (1.0 - (ratio * skew_bps / 10_000.0));
    let half = reservation * (spread_bps / 10_000.0);
    let mut bid = round_to_tick(reservation - half, tick);
    let mut ask = round_to_tick(reservation + half, tick);
    if bid >= fair {
        bid = round_to_tick(fair - tick, tick);
    }
    if ask <= fair {
        ask = round_to_tick(fair + tick, tick);
    }
    if bid <= 0.0 || ask <= bid {
        return Err(format!("invalid quotes fair={fair} bid={bid} ask={ask}"));
    }
    Ok((reservation, bid, ask))
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    tracing_subscriber::fmt()
        .with_env_filter(
            env::var("RUST_LOG").unwrap_or_else(|_| "vanilla_mm_rust=info,godark=warn".into()),
        )
        .init();

    let symbol = env_first(&["GODARK_DEVNET_SYMBOL", "GODARK_SYMBOL"])
        .unwrap_or_else(|| DEFAULT_SYMBOL.to_string());
    let loop_sec = env_f64("MM_LOOP_INTERVAL_SEC", 10.0);
    let order_qty = env_f64("MM_ORDER_QTY", 0.01);
    let max_inv = env_f64("MM_MAX_INVENTORY", 0.05);
    let half_bps = env_f64("MM_HALF_SPREAD_BPS", 50.0);
    let skew_bps = env_f64("MM_INVENTORY_SKEW_BPS", 5.0);
    let maker_fee_bps = env_f64("MM_MAKER_FEE_BPS", 2.0);
    let tick = env_f64("MM_TICK_SIZE", 0.01);
    let spread_bps = half_spread_bps(half_bps, maker_fee_bps);
    let fair = env_first(&["MM_FAIR_OVERRIDE"])
        .and_then(|s| s.parse().ok())
        .unwrap_or(64_000.0);

    let mut client = build_rest_client()?;
    client.connect().await?;
    info!(
        "REST connected user_uuid={:?} hpke_pin={}",
        client.user_uuid(),
        if hpke_pin().is_some() { "set" } else { "MISSING" }
    );

    let mut bid_coid: Option<String> = None;
    let mut ask_coid: Option<String> = None;
    let mut interval = tokio::time::interval(Duration::from_secs_f64(loop_sec.max(5.0)));

    loop {
        tokio::select! {
            _ = signal::ctrl_c() => {
                info!("shutdown");
                break;
            }
            _ = interval.tick() => {}
        }

        let (reservation, bid, ask) = match quote_prices(fair, 0.0, max_inv, spread_bps, skew_bps, tick)
        {
            Ok(q) => q,
            Err(e) => {
                error!("quote math: {e}");
                continue;
            }
        };

        info!(
            "quote fair={fair:.2} res={reservation:.2} bid={bid:.2} ask={ask:.2} spread_bps={spread_bps:.1}"
        );

        for coid in [bid_coid.take(), ask_coid.take()].into_iter().flatten() {
            if let Err(e) = client.cancel_order_by_client_id(&coid, &symbol).await {
                warn!("cancel {coid}: {e}");
            }
        }

        let new_bid_coid = format!("mm-bid-{}", uuid::Uuid::new_v4());
        match client
            .place_order(
                &symbol,
                Side::Buy,
                OrderType::Limit,
                order_qty,
                Some(bid),
                TimeInForce::Gtc,
                false,
                None,
                None,
                Some(new_bid_coid.clone()),
            )
            .await
        {
            Ok(ack) => {
                info!("bid placed coid={new_bid_coid} order_id={}", ack.order_id);
                bid_coid = Some(new_bid_coid);
            }
            Err(e) => error!("bid place failed: {e}"),
        }

        let new_ask_coid = format!("mm-ask-{}", uuid::Uuid::new_v4());
        match client
            .place_order(
                &symbol,
                Side::Sell,
                OrderType::Limit,
                order_qty,
                Some(ask),
                TimeInForce::Gtc,
                false,
                None,
                None,
                Some(new_ask_coid.clone()),
            )
            .await
        {
            Ok(ack) => {
                info!("ask placed coid={new_ask_coid} order_id={}", ack.order_id);
                ask_coid = Some(new_ask_coid);
            }
            Err(e) => error!("ask place failed: {e}"),
        }
    }

    client.disconnect().await.ok();
    Ok(())
}
