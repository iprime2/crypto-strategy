#!/usr/bin/env bash
# Start vanilla GoDark MM bot (Rust / HPKE) on devnet.
set -euo pipefail

source ~/scripts/source-secrets.sh
export GODARK_ENV="${GODARK_ENV:-devnet}"

# HPKE pin + URLs (do not invent pin — must match deployed frontend for this host)
eval "$(python3 ~/scripts/mms/godark-resolve-auth.py --export)"
export GDX_HPKE_STATIC_PUBLIC_KEY="${GDX_HPKE_STATIC_PUBLIC_KEY:-${GODARK_DEVNET_HPKE_STATIC_PUBLIC_KEY:-}}"
export GODARK_DEVNET_EDGE_URL="${GODARK_DEVNET_EDGE_URL:-wss://api.devnet.godark-dex.com}"

# Credentials for Rust builder (GODARK_* aliases)
export GODARK_API_KEY_ID="${GODARK_DEVNET_API_KEY_ID}"
export GODARK_API_SECRET="${GODARK_DEVNET_API_SECRET}"
export GODARK_PASSPHRASE="${GODARK_DEVNET_PASSPHRASE}"
export GODARK_EDGE_URL="${GDX_EDGE_URL}"

# user_uuid: omit unless auth omits it — connect() fills from login when present.
unset GODARK_USER_UUID 2>/dev/null || true

# Conservative devnet defaults — override via env
export MM_FAIR_OVERRIDE="${MM_FAIR_OVERRIDE:-64000}"
export MM_ORDER_QTY="${MM_ORDER_QTY:-0.01}"
export MM_LOOP_INTERVAL_SEC="${MM_LOOP_INTERVAL_SEC:-10}"
export RUST_LOG="${RUST_LOG:-vanilla_mm_rust=info,godark=warn}"

cd ~/scripts/mms/vanilla-mm-rust
exec cargo run --release
